package com.mycompany.a2;

public interface ISteerable {
	public void steerRight();
	public void steerLeft();

}
